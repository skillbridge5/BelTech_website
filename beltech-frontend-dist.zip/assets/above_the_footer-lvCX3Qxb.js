const e="/assets/above_the_footer-HEVBX6Ku.jpg";export{e as a};
