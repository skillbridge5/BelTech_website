const s="/assets/skillBridge-mark-CiwiooBO.png";export{s};
