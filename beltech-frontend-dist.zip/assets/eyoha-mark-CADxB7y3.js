const a="/assets/eyoha-mark-CfWLoxRS.png";export{a as e};
