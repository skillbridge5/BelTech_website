import{c as r,a as d,j as e,X as p,S as f,n as g}from"./index-Ce_BYk_s.js";import{z as l}from"./index-D6LHs0w0.js";/**
 * @license lucide-react v0.539.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const x=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2",key:"1m3agn"}],["circle",{cx:"9",cy:"9",r:"2",key:"af1f0g"}],["path",{d:"m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21",key:"1xmnt7"}]],h=r("image",x);/**
 * @license lucide-react v0.539.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=[["path",{d:"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",key:"1a8usu"}],["path",{d:"m15 5 4 4",key:"1mk7zo"}]],v=r("pencil",u);/**
 * @license lucide-react v0.539.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]],w=r("plus",y);/**
 * @license lucide-react v0.539.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const b=[["path",{d:"M12 3v12",key:"1x0j5s"}],["path",{d:"m17 8-5-5-5 5",key:"7q97r8"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}]],j=r("upload",b),I=({value:s,onChange:o})=>{const[n,i]=d.useState(!1),t=d.useRef(null),m=async a=>{if(a){if(!a.type.startsWith("image/")){l.error("Please choose an image file",{style:{background:"#D82727",color:"#ffffff"}});return}i(!0);try{const c=await f(a);o(c),l.success("Image uploaded",{style:{background:"#059669",color:"#ffffff"}})}catch(c){l.error(g(c,"Upload failed"),{style:{background:"#D82727",color:"#ffffff"}})}finally{i(!1),t.current&&(t.current.value="")}}};return e.jsxs("div",{className:"space-y-3",children:[e.jsxs("div",{className:"flex items-start gap-4",children:[e.jsx("div",{className:"h-28 w-40 rounded-lg overflow-hidden border border-gray-200 bg-gray-100 flex items-center justify-center shrink-0",children:s?e.jsx("img",{src:s,alt:"Preview",className:"h-full w-full object-cover"}):e.jsx(h,{className:"h-8 w-8 text-gray-300"})}),e.jsxs("div",{className:"flex flex-col gap-2",children:[e.jsx("input",{ref:t,type:"file",accept:"image/*",className:"hidden",onChange:a=>m(a.target.files?.[0])}),e.jsx("button",{type:"button",onClick:()=>t.current?.click(),disabled:n,className:"inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-gray-300 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-60",children:n?e.jsxs(e.Fragment,{children:[e.jsx("span",{className:"h-4 w-4 border-2 border-gray-300 border-t-[#0078B7] rounded-full animate-spin"}),"Uploading..."]}):e.jsxs(e.Fragment,{children:[e.jsx(j,{className:"h-4 w-4"}),s?"Replace Image":"Upload Image"]})}),s&&e.jsxs("button",{type:"button",onClick:()=>o(""),className:"inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-red-600 hover:bg-red-50",children:[e.jsx(p,{className:"h-4 w-4"}),"Remove image"]})]})]}),e.jsx("p",{className:"text-xs text-gray-500",children:"Or paste an image URL below:"})]})};export{I,w as P,v as a};
