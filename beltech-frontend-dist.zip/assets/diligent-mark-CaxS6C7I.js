const s="/assets/diligent-mark-RVx5-8so.png";export{s as d};
